function createMusicCard(music, index) {
  const card = document.createElement('div')
  card.className = 'music-card'
  card.dataset.index = index
  card.dataset.musicId = music.id // Important pour GEST
  
  const duration = music.duration ? formatTime(music.duration) : '--:--'
  const fileSize = music.file_size ? formatFileSize(music.file_size) : ''
  
  card.innerHTML = `
        <div class="music-cover">
            <i class="fas fa-music"></i>
        </div>
        <div class="music-info">
            <div class="music-title" title="${music.title}">${music.title}</div>
            <div class="music-artist">${music.artist || 'Artiste inconnu'}</div>
            <div class="music-meta">
                <span class="music-duration">${duration}</span>
                ${fileSize ? `<span class="music-size">${fileSize}</span>` : ''}
            </div>
        </div>
    `
  
  // Ajouter les boutons de gestion
  if (window.Gest) {
    // Bouton suppression
    const deleteBtn = window.Gest.createDeleteButton(music.id, music.file_path)
    card.style.position = 'relative'
    card.appendChild(deleteBtn)
    
    // Bouton téléchargement
    const downloadBtn = window.Gest.createDownloadButton(
      music.id,
      music.file_path,
      music.file_name,
      music.title
    )
    card.appendChild(downloadBtn)
    
    // Gérer l'affichage des boutons au hover
    card.addEventListener('mouseenter', () => {
      deleteBtn.style.opacity = '1'
      deleteBtn.style.transform = 'scale(1)'
      downloadBtn.style.opacity = '1'
      downloadBtn.style.transform = 'scale(1)'
    })
    
    card.addEventListener('mouseleave', () => {
      deleteBtn.style.opacity = '0'
      deleteBtn.style.transform = 'scale(0.8)'
      downloadBtn.style.opacity = '0'
      downloadBtn.style.transform = 'scale(0.8)'
    })
  }
  
  // Événements de lecture
  card.addEventListener('click', (e) => {
    // Ne pas déclencher la lecture si on clique sur un bouton de gestion
    if (!e.target.closest('.btn-delete-music, .btn-download-music')) {
      selectAndPlayMusic(index)
    }
  })
  
  return card
}